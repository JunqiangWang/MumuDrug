library(testthat)
library(MumuDrug)

test_check("MumuDrug")
